package com.example.testculturageneral;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;//Se importan las librerías que se ocuparon
import android.widget.Toast;

//Es el activity principal, los demás activity's contienen el mismo código, con sus respectivas respuestas correctas o incorrectas

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = (Button)findViewById(R.id.btnRespuesta1);//Se castea(obligar a ser un tipo de dato) la variable que vamos a ocupar
        //y buscar en la vista por id el boton nombrado en el activity
        btn.setOnClickListener(new View.OnClickListener() {//Se crea el evento para que cuando se de un clic haga su respectivo objetivo
            @Override//Se genera por android automaticamente
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();// Manda un mensaje con el contexto y el texto que se va a mostrar
            }// con una duracion larga en el mensaje.
        });
        
        Button btn2 = (Button)findViewById(R.id.btnRespuesta2);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn3 =(Button)findViewById(R.id.btnRespuesta3);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Respuesta correcta", Toast.LENGTH_LONG).show();
            }
        });

        Button btn4 = (Button)findViewById(R.id.btnRespuestaAzteca);
        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn5 = (Button)findViewById(R.id.btnRespuestaItalianos);
        btn5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn6 = (Button)findViewById(R.id.btnRespuestaImperio);
        btn6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Respuesta correcta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn7 =(Button)findViewById(R.id.btnRespuestaMetal);
        btn7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn8 = (Button)findViewById(R.id.btnRespuestaDon);
        btn8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Respuesta correcta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn9 = (Button)findViewById(R.id.btnRespuestaContra);
        btn9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn10= (Button)findViewById(R.id.btnRespuestaAlaska);
        btn10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn11= (Button)findViewById(R.id.btnRespuestaPolo);
        btn11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn12= (Button)findViewById(R.id.btnRespuestaAntar);
        btn12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Respuesta correcta", Toast.LENGTH_LONG).show();
            }
        });
            Button btnSiguiente2= (Button)findViewById(R.id.btnSiguiente2);//Intent se le pasa un contexto y a que activity se dirige
            btnSiguiente2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(v.getContext(),MainActivity2.class);//Se le pasan dos valores, el contexto y el nombre del activity a donde va
                    startActivity(intent);
                }
            });
    }
}