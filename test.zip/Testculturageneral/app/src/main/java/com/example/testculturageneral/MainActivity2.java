package com.example.testculturageneral;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Button btn13= (Button)findViewById(R.id.btnRespuesta234);
        btn13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn14= (Button)findViewById(R.id.btnRespuesta206);
        btn14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "Respuesta correcta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn15=(Button)findViewById(R.id.btnRespuesta345);
        btn15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn16=(Button)findViewById(R.id.btnRespuestaRevisteria);
        btn16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn17=(Button)findViewById(R.id.btnRespuestaAlmacen);
        btn17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn18=(Button)findViewById(R.id.btnRespuestaHemero);
        btn18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "Respuesta correcta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn19=(Button)findViewById(R.id.btnRespuesta1939);
        btn19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "Respuesta correcta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn20=(Button)findViewById(R.id.btnRespuesta1943);
        btn20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn21=(Button)findViewById(R.id.btnRespuesta1892);
        btn21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn22=(Button)findViewById(R.id.btnRespuesta42);
        btn22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn23=(Button)findViewById(R.id.btnRespuesta51);
        btn23.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn24=(Button)findViewById(R.id.btnRespuesta50);
        btn24.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity2.this, "Respuesta correcta", Toast.LENGTH_LONG).show();
            }
        });
        Button btnSiguiente3= (Button)findViewById(R.id.btnSiguiente3);
        btnSiguiente3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(),MainActivity3.class);
                startActivity(intent);
            }
        });
    }
}