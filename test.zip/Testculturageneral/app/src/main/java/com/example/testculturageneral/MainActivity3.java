package com.example.testculturageneral;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Button btn25 = (Button)findViewById(R.id.btnRespuestaProton);
        btn25.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity3.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn26 = (Button)findViewById(R.id.btnRespuestaMolecula);
        btn26.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity3.this, "Respuesta correcta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn27 = (Button)findViewById(R.id.btnRespuestaAtomo);
        btn27.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity3.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn28 = (Button)findViewById(R.id.btnRespuestaOro);
        btn28.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity3.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn29 = (Button)findViewById(R.id.btnRespuestaRodio);
        btn29.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity3.this, "Respuesta correcta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn30 = (Button)findViewById(R.id.btnRespuestaPLata);
        btn30.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity3.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn31 = (Button)findViewById(R.id.btnRespuestaTailandia);
        btn31.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity3.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn32 = (Button)findViewById(R.id.btnRespuestaHong);
        btn32.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity3.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn33 = (Button)findViewById(R.id.btnRespuestaTokio);
        btn33.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity3.this, "Respuesta correcta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn34 = (Button)findViewById(R.id.btnRespuestaCreci);
        btn34.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity3.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn35 = (Button)findViewById(R.id.btnRespuestaAli);
        btn35.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity3.this, "Respuesta correcta", Toast.LENGTH_LONG).show();
            }
        });
        Button btn36 = (Button)findViewById(R.id.btnRespuestadesa);
        btn36.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity3.this, "Respuesta incorrecta", Toast.LENGTH_LONG).show();
            }
        });
    }
}